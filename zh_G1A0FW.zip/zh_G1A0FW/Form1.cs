using CsvHelper;
using System.ComponentModel;
using System.Globalization;

namespace zh_G1A0FW
{
    public partial class Form1 : Form
    {
        BindingList<bolygo> bo = new();
        public int elet = 0;
        public int maxim = int.MaxValue;
        public int atmero = 0;
        public bool igaz;
        public Form1()
        {
            InitializeComponent();
            //dataGridView1.DataSource = bo;
            bolygoBindingSource.DataSource = bo;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                StreamReader sr = new StreamReader("bolygo.csv");
                var csv = new CsvReader(sr, CultureInfo.InvariantCulture);
                var t�mb = csv.GetRecords<bolygo>();

                foreach (var item in t�mb)
                {
                    bo.Add(item);

                }

                sr.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            try
            {
                SaveFileDialog SFD = new SaveFileDialog();
                if (SFD.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter sw = new StreamWriter(SFD.FileName);
                    var csv = new CsvWriter(sw, CultureInfo.InvariantCulture);
                    csv.WriteRecords(bo);

                    sw.Close();
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (bolygoBindingSource.Current == null) return;

            if (MessageBox.Show("J�v�hagyod a t�rl�st", "T�rl�s", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                bolygoBindingSource.RemoveCurrent();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormAdd formAdd = new FormAdd();
            formAdd.ShowDialog();
            bo.Add(formAdd.UjAdat);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var item in bo)
            {
                if (item.VanElet == true)
                {
                    elet++;
                }
                if (item.AtmeroKM < maxim)
                {
                    maxim = item.AtmeroKM;
                }
                if (item.AtmeroKM == maxim)
                {
                    igaz = item.VanElet;

                }

            }

            if (igaz == false)
            {
                MessageBox.Show($"A legkisebb bolyg� �tm�r�je {maxim} �s nincs rajta �let. �sszesen {elet} bolyg�n van �let");
            }
            else
            {
                MessageBox.Show($"A legkisebb bolyg� �tm�r�je {maxim} �s van rajta �let. �sszesen {elet} bolyg�n van �let");
            }
        }

    }
}