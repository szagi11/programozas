﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zh_G1A0FW
{
    public partial class FormAdd : Form
    {
        public bolygo UjAdat { get; set; }
        public FormAdd()
        {
            InitializeComponent();
            UjAdat = new bolygo();
           
        }
        private void button1_Click(object sender, EventArgs e)
        {
            bindingSource1.DataSource = UjAdat;
        }

    }
}
