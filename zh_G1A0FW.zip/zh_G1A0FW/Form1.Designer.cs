﻿namespace zh_G1A0FW
{
    partial class Form1
    {
        private const string V = "Form1";

        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataGridView1 = new DataGridView();
            bolygoIDDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            nevDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            tavolsagNaptolAUDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            atmeroKMDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            vanEletDataGridViewCheckBoxColumn = new DataGridViewCheckBoxColumn();
            bolygoBindingSource = new BindingSource(components);
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)bolygoBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { bolygoIDDataGridViewTextBoxColumn, nevDataGridViewTextBoxColumn, tavolsagNaptolAUDataGridViewTextBoxColumn, atmeroKMDataGridViewTextBoxColumn, vanEletDataGridViewCheckBoxColumn });
            dataGridView1.DataSource = bolygoBindingSource;
            dataGridView1.Location = new Point(39, 150);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(816, 225);
            dataGridView1.TabIndex = 0;
            // 
            // bolygoIDDataGridViewTextBoxColumn
            // 
            bolygoIDDataGridViewTextBoxColumn.DataPropertyName = "BolygoID";
            bolygoIDDataGridViewTextBoxColumn.HeaderText = "BolygoID";
            bolygoIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            bolygoIDDataGridViewTextBoxColumn.Name = "bolygoIDDataGridViewTextBoxColumn";
            bolygoIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // nevDataGridViewTextBoxColumn
            // 
            nevDataGridViewTextBoxColumn.DataPropertyName = "Nev";
            nevDataGridViewTextBoxColumn.HeaderText = "Nev";
            nevDataGridViewTextBoxColumn.MinimumWidth = 8;
            nevDataGridViewTextBoxColumn.Name = "nevDataGridViewTextBoxColumn";
            nevDataGridViewTextBoxColumn.Width = 150;
            // 
            // tavolsagNaptolAUDataGridViewTextBoxColumn
            // 
            tavolsagNaptolAUDataGridViewTextBoxColumn.DataPropertyName = "TavolsagNaptolAU";
            tavolsagNaptolAUDataGridViewTextBoxColumn.HeaderText = "TavolsagNaptolAU";
            tavolsagNaptolAUDataGridViewTextBoxColumn.MinimumWidth = 8;
            tavolsagNaptolAUDataGridViewTextBoxColumn.Name = "tavolsagNaptolAUDataGridViewTextBoxColumn";
            tavolsagNaptolAUDataGridViewTextBoxColumn.Width = 150;
            // 
            // atmeroKMDataGridViewTextBoxColumn
            // 
            atmeroKMDataGridViewTextBoxColumn.DataPropertyName = "AtmeroKM";
            atmeroKMDataGridViewTextBoxColumn.HeaderText = "AtmeroKM";
            atmeroKMDataGridViewTextBoxColumn.MinimumWidth = 8;
            atmeroKMDataGridViewTextBoxColumn.Name = "atmeroKMDataGridViewTextBoxColumn";
            atmeroKMDataGridViewTextBoxColumn.Width = 150;
            // 
            // vanEletDataGridViewCheckBoxColumn
            // 
            vanEletDataGridViewCheckBoxColumn.DataPropertyName = "VanElet";
            vanEletDataGridViewCheckBoxColumn.HeaderText = "VanElet";
            vanEletDataGridViewCheckBoxColumn.MinimumWidth = 8;
            vanEletDataGridViewCheckBoxColumn.Name = "vanEletDataGridViewCheckBoxColumn";
            vanEletDataGridViewCheckBoxColumn.Width = 150;
            // 
            // bolygoBindingSource
            // 
            bolygoBindingSource.DataSource = typeof(bolygo);
            // 
            // button1
            // 
            button1.Location = new Point(12, 81);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 1;
            button1.Text = "Érdekesség";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(482, 81);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 2;
            button2.Text = "Mentés";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(648, 81);
            button3.Name = "button3";
            button3.Size = new Size(112, 34);
            button3.TabIndex = 3;
            button3.Text = "Beolvasás";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(470, 393);
            button4.Name = "button4";
            button4.Size = new Size(112, 34);
            button4.TabIndex = 4;
            button4.Text = "Törlés";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(635, 393);
            button5.Name = "button5";
            button5.Size = new Size(112, 34);
            button5.TabIndex = 5;
            button5.Text = "Új sor";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(890, 450);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)bolygoBindingSource).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private DataGridViewTextBoxColumn bolygoIDDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn nevDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn tavolsagNaptolAUDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn atmeroKMDataGridViewTextBoxColumn;
        private DataGridViewCheckBoxColumn vanEletDataGridViewCheckBoxColumn;
        private BindingSource bolygoBindingSource;
    }
}
