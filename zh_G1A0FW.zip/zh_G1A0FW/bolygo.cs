﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zh_G1A0FW
{
    public class bolygo
    {
        public int BolygoID { get; set; }

        public string Nev { get; set; }

        public double TavolsagNaptolAU { get; set; }

        public int AtmeroKM { get; set; }

        public bool VanElet { get; set; }
    }
}
